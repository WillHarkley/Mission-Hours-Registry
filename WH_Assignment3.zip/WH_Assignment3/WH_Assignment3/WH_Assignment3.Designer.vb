﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmWH_Assignment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtPpl = New System.Windows.Forms.TextBox()
        Me.txtHmh = New System.Windows.Forms.TextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.lblpeople = New System.Windows.Forms.Label()
        Me.lblhours = New System.Windows.Forms.Label()
        Me.cboMissions = New System.Windows.Forms.ComboBox()
        Me.lstDisplay = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'txtPpl
        '
        Me.txtPpl.AcceptsReturn = True
        Me.txtPpl.AcceptsTab = True
        Me.txtPpl.Location = New System.Drawing.Point(430, 117)
        Me.txtPpl.Multiline = True
        Me.txtPpl.Name = "txtPpl"
        Me.txtPpl.Size = New System.Drawing.Size(107, 56)
        Me.txtPpl.TabIndex = 17
        '
        'txtHmh
        '
        Me.txtHmh.AcceptsReturn = True
        Me.txtHmh.AcceptsTab = True
        Me.txtHmh.Location = New System.Drawing.Point(227, 117)
        Me.txtHmh.Multiline = True
        Me.txtHmh.Name = "txtHmh"
        Me.txtHmh.Size = New System.Drawing.Size(100, 56)
        Me.txtHmh.TabIndex = 15
        '
        'btnClose
        '
        Me.btnClose.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnClose.Location = New System.Drawing.Point(495, 357)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(79, 33)
        Me.btnClose.TabIndex = 21
        Me.btnClose.Text = "Clos&e"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnClear.Location = New System.Drawing.Point(346, 357)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(79, 33)
        Me.btnClear.TabIndex = 20
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnCalc.Location = New System.Drawing.Point(193, 357)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(89, 33)
        Me.btnCalc.TabIndex = 19
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'lblpeople
        '
        Me.lblpeople.AutoSize = True
        Me.lblpeople.Location = New System.Drawing.Point(436, 101)
        Me.lblpeople.Name = "lblpeople"
        Me.lblpeople.Size = New System.Drawing.Size(92, 13)
        Me.lblpeople.TabIndex = 14
        Me.lblpeople.Text = "Number of People"
        '
        'lblhours
        '
        Me.lblhours.AutoSize = True
        Me.lblhours.Location = New System.Drawing.Point(241, 101)
        Me.lblhours.Name = "lblhours"
        Me.lblhours.Size = New System.Drawing.Size(86, 13)
        Me.lblhours.TabIndex = 13
        Me.lblhours.Text = "How many hours"
        '
        'cboMissions
        '
        Me.cboMissions.FormattingEnabled = True
        Me.cboMissions.Items.AddRange(New Object() {"Cooking", "Item Inventory", "Construction"})
        Me.cboMissions.Location = New System.Drawing.Point(299, 63)
        Me.cboMissions.Name = "cboMissions"
        Me.cboMissions.Size = New System.Drawing.Size(149, 21)
        Me.cboMissions.TabIndex = 24
        Me.cboMissions.Text = "Missions"
        '
        'lstDisplay
        '
        Me.lstDisplay.FormattingEnabled = True
        Me.lstDisplay.Location = New System.Drawing.Point(212, 190)
        Me.lstDisplay.Name = "lstDisplay"
        Me.lstDisplay.Size = New System.Drawing.Size(343, 134)
        Me.lstDisplay.TabIndex = 25
        '
        'frmWH_Assignment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSlateGray
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lstDisplay)
        Me.Controls.Add(Me.cboMissions)
        Me.Controls.Add(Me.txtPpl)
        Me.Controls.Add(Me.txtHmh)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblpeople)
        Me.Controls.Add(Me.lblhours)
        Me.Name = "frmWH_Assignment"
        Me.Text = "Assignment 3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPpl As TextBox
    Friend WithEvents txtHmh As TextBox
    Friend WithEvents btnClose As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents lblpeople As Label
    Friend WithEvents lblhours As Label
    Friend WithEvents cboMissions As ComboBox
    Friend WithEvents lstDisplay As ListBox
End Class
