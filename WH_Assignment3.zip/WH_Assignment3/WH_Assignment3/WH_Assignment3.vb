﻿Public Class frmWH_Assignment

    'Name: WH Assignment 3
    'Purpose: To provide the remaining hours left to complete the missions work and the total number of hours completed while keeping record of the namesof the people on tasks
    'Programmer: William Harkley

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Declare Variables
        Dim dblhrs, dblpeople, dblmission, dbltotal, dblremain As Double
        Dim strmissions As String

        'txtHmh.Text = dblhrs
        If txtHmh.Text = "" Then
            MessageBox.Show("Please enter the number of hours")
            txtHmh.Focus()
            Return
        End If

        'txtPpl.Text = dblpeople
        If txtPpl.Text = "" Then
            MessageBox.Show("Please enter the number of people")
            txtPpl.Focus()
            Return
        End If


        If cboMissions.SelectedIndex = -1 Then
            MessageBox.Show("Please select a mission")
            Return
        Else
            strmissions = cboMissions.SelectedItem
        End If




        'Set Variable

        Integer.TryParse(txtHmh.Text, dblhrs)
        Integer.TryParse(txtPpl.Text, dblpeople)

#Disable Warning BC42104 ' Variable is used before it has been assigned a value
        dblmission = getMissionHours(strmissions)
#Enable Warning BC42104 ' Variable is used before it has been assigned a value

        'Calculation

        'Total hours = hours entered * number of people

        dbltotal = dblhrs * dblpeople
        dblremain = dblmission - dbltotal

        remainingDisplay(dblremain)

        lstDisplay.Items.Add("The mission you chose is " & strmissions)
        lstDisplay.Items.Add("The total mission hours are " & dblmission)
        lstDisplay.Items.Add("The total number of hours completed are " & dbltotal)
        lstDisplay.Items.Add("Your total amount of hours remaining are " & dblremain)

        For i As Integer = 1 To dblpeople
            InputBox("Please enter a name")
        Next


    End Sub

    Private Sub remainingDisplay(ByVal dblremain As Double)
        'Display
        If dblremain < 0 Then
            MessageBox.Show("You have completed the required hours")
        Else
            MessageBox.Show("Keep up the good work!")
        End If

    End Sub


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        cboMissions.SelectedIndex = -1
        lstDisplay.Items.Clear()
        txtHmh.Text = ""
        txtPpl.Text = ""
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Function getMissionHours(ByVal strmissions As String) As Integer
        Dim dblmissions As Integer
#Disable Warning BC42104 ' Variable is used before it has been assigned a value
        Select Case strmissions
#Enable Warning BC42104 ' Variable is used before it has been assigned a value
            Case "Cooking"
                dblmissions = 350

            Case "Item Inventory"
                dblmissions = 200

            Case "Construction"
                dblmissions = 400
            Case Else
                MessageBox.Show("Please enter a mission ")

        End Select
        Return dblmissions
    End Function

End Class